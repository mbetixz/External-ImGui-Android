#ifndef decl_h
#define decl_h

static float Speed = 1;

#endif
